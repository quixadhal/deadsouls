/* this file was manually generated -- don't delete it */

INLINE void f_ge PROT((void));
INLINE void f_le PROT((void));
INLINE void f_lt PROT((void));
INLINE void f_gt PROT((void));
INLINE void f_and PROT((void));
INLINE void f_and_eq PROT((void));
INLINE void f_div_eq PROT((void));
INLINE void f_eq PROT((void));
INLINE void f_lsh PROT((void));
INLINE void f_lsh_eq PROT((void));
INLINE void f_mod_eq PROT((void));
INLINE void f_mult_eq PROT((void));
INLINE void f_ne PROT((void));
INLINE void f_or PROT((void));
INLINE void f_or_eq PROT((void));
INLINE void f_parse_command PROT((void));
INLINE void f_range PROT((int));
INLINE void f_extract_range PROT((int));
INLINE void f_rsh PROT((void));
INLINE void f_rsh_eq PROT((void));
INLINE void f_simul_efun PROT((void));
INLINE void f_sub_eq PROT((void));
INLINE void f_switch PROT((void));
INLINE void f_xor PROT((void));
INLINE void f_xor_eq PROT((void));
INLINE void f_function_constructor PROT((void));
INLINE void f_evaluate PROT((void));
INLINE void f_sscanf PROT((void));

/*
 * eoperators.c
 */
void call_simul_efun PROT((unsigned short, int));

