void do_tests() {
    ASSERT(objectp(this_object()));
    ASSERT(!objectp(0));
}

