void foo() {
    for (void x = 1; ; ) ;
}
