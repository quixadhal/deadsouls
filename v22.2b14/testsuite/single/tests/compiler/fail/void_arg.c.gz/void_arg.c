void foo(void x) {
}
