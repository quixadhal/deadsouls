TYPETEST

int foo() {
    return "hi";
}
