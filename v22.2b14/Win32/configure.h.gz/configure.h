#define INCL_STDLIB_H
#define INCL_TIME_H
#define INCL_FCNTL_H
#define INCL_DOS_H
#define INCL_LIMITS_H
#define USE_STRUCT_DIRENT
#define INCL_SYS_STAT_H
#define INCL_STDARG_H
#define HAS_MEMMOVE
#define RAND
#define HAS_STRERROR
#define HAS_GETCWD

#define CONST const
#define INLINE
#define UINT32 unsigned long
#define UINT32 unsigned long
