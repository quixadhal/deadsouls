#ifndef HASH_H
#define HASH_H

/*
 * hash.c
 */
int hashstr PROT((char *, int, int));
int whashstr PROT((char *, int));

#endif
