#define INCL_STDLIB_H
#define INCL_TIME_H
#define INCL_FCNTL_H
#define INCL_DOS_H
#define INCL_SYS_STAT_H
#define INCL_LIMITS_H
#define USE_STRUCT_DIRENT
#define INCL_STDARG_H
#define HAS_MEMMOVE
#define RAND
#define HAS_STRERROR
#define HAS_GETCWD

#define SIZEOF_INT 4
#define SIZEOF_PTR 4
#define SIZEOF_SHORT 2
#define SIZEOF_FLOAT 4
