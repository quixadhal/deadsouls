#ifndef QSORT_H
#define QSORT_H

/*
 * qsort.c
 */
void quickSort PROT((void *, int, int, int (*) ()));

#endif
